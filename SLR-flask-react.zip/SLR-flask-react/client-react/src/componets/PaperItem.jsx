/*eslint-disable*/
import styles from "./PaperItem.module.css";
function PaperItem({ paper }) {
  return (
    <li
      className={
        paper.keywordsCount >= 5 ? styles.mostRelated : styles.PaperItem
      }
    >
      <span>{paper.id} </span>
      <em className={styles.em}>{paper.keywordsCount} </em>
      <span>{paper.title} </span>
      <span>
        <a target="_blank" href={`${paper.link}`}>
          link
        </a>
      </span>
    </li>
  );
}

export default PaperItem;
