from flask import Flask,render_template,request,redirect,jsonify,make_response
import pandas as pd
import json
import string
from nltk.corpus import stopwords
from nltk.tokenize import word_tokenize
import re
import collections

app=Flask(__name__)



@app.route("/")
def index():
    return render_template("index.html")

@app.route("/uploadDone")
def uploadDone():
     return render_template("uploadDone.html")

# send json , return as object
@app.route("/dataset",methods=['GET','POST'])
def dataset():
    data = []
    with open('dataset.json') as f:
        for line in f:
            data.append(json.loads(line))
    return make_response(jsonify(data), 200)

       
dataset_xlsx = 'uploads/paper-collection.xlsx'

# transform xlsx to json, as dataset for react
def to_json():
    excel_data_df = pd.read_excel(dataset_xlsx)
    # Convert excel to string (define orientation of document in this case from up to down)
    this_is_json = excel_data_df.to_json(orient='records')
    #  Make the string into a list to be able to input in to a JSON-file
    this_is_json_dict = json.loads(this_is_json)
    # with open('paper-collection.json', 'w') as json_file:
    with open('dataset.json', 'w') as json_file:
       json.dump(this_is_json_dict, json_file)  
    return ''  # call but render nothing


# remove stopwords, get clean text
def remove_stopwords(text): 
      lower_case = text.lower()
      clean_text = lower_case.translate(str.maketrans('', '', string.punctuation))
    # tokenize
      tokenized_words = word_tokenize(clean_text)
    # remove stopwords
      stop_words = set(stopwords.words('english'))
      withoutStopwords = []
      for word in tokenized_words:
        if word not in stop_words:
            withoutStopwords.append(word)
            sw_removed = ' '.join(withoutStopwords)
    
      return sw_removed

def count_frequency(clean_text,most):
    words = re.findall(r'\w+',clean_text)
    most_common = collections.Counter(words).most_common(most)
    return most_common


# ########### keywords extraction ###################
def get_keywords(column_name,most=10): # set a optional para
    text=""
    A = pd.read_excel(dataset_xlsx)
    for index,r in A.iterrows():
        # print(r[column_name])
        text += str(r[column_name])
    # remove stops
    remove_sw_text = remove_stopwords(text)
    # get keywords
    keywords=count_frequency(remove_sw_text,most)
    # return "title.txt has been created"
    return keywords
 

@app.context_processor
def context_processor():
    # even not called in templates, must registerd here
    return dict(key="value",to_json=to_json,remove_stopwords=remove_stopwords,count_frequency=count_frequency,get_keywords=get_keywords)

#-------------------------------    

@app.route('/upload',methods=['POST','GET'])
def upload():
    file=request.files['file']  
    file.filename = "paper-collection.xlsx"
    file.save(f'uploads/{file.filename}')
    return render_template('uploadDone.html',var1=file.filename)
 

if __name__=="__main__":
    app.run()