/*eslint-disable*/
import styles from "./Papers.module.css";
import PaperItem from "./PaperItem";
// helper functon-- sorting
function compare(a, b) {
  if (a.totalKeys < b.totalKeys) {
    return 1;
  }
  if (a.totalKeys > b.totalKeys) {
    return -1;
  }
  return 0;
}

function Papers({ displayList }) {
  return (
    <div className={styles.papersContainer}>
      <p>
        Related papers 📃:
        {displayList.length > 0
          ? `${displayList.length}`
          : "Click sidebar to see related papers."}
      </p>

      {displayList.map((paper) => (
        <PaperItem paper={paper} key={paper.id} />
      ))}
    </div>
  );
}

export default Papers;
