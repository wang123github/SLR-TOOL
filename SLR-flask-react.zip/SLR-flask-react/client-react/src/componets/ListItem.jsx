// import styles from "./ListItem.module.css";
function ListItem({ paper }) {
  return <li>{paper}</li>;
}

export default ListItem;
