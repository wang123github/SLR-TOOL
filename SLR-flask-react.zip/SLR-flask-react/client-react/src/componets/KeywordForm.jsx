import { useState } from "react";
import styles from "./KeywordForm.module.css";
import { useNavigate } from "react-router-dom";
/*eslint-disable*/
function KeywordForm({ setKw }) {
  const [kw01, setKw01] = useState();
  const [kw02, setKw02] = useState();
  const [kw03, setKw03] = useState();

  const navigate = useNavigate();

  function handleSubmit(e) {
    e.preventDefault();
    const kwOBj = setKw({ kw01, kw02, kw03 });
    navigate("research");
  }

  return (
    <form className={styles.form} onSubmit={handleSubmit}>
      <div>
        <label htmlFor="kw01">Keyword 01:</label>
        <input
          id="kw01"
          value={kw01}
          onChange={(e) => setKw01(e.target.value)}
          autoFocus
          placeholder="type in 1st keyword"
        ></input>
      </div>

      <div>
        <label htmlFor="kw02">Keyword 02:</label>
        <input
          id="kw02"
          value={kw02}
          onChange={(e) => setKw02(e.target.value)}
          placeholder="type in 2nd keyword"
        ></input>
      </div>

      <div>
        <label htmlFor="kw03">Keyword 03:</label>
        <input
          id="kw03"
          value={kw03}
          onChange={(e) => setKw03(e.target.value)}
          placeholder="type in 3rd keyword"
        ></input>
      </div>

      <div>
        <button>Submit</button>
      </div>
    </form>
  );
}

export default KeywordForm;
