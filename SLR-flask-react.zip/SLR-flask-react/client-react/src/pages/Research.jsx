/*eslint-disable*/
import Nav from "../componets/Nav";
import Sidebar from "../componets/Sidebar";
import Papers from "../componets/Papers";
import styles from "./Research.module.css";
import { useState } from "react";

// ########======  Research Component ====######
function Research({ kw }) {
  const [displayList, setDisplayList] = useState([]);
  return (
    <div className={styles.container}>
      <Nav />
      <div className={styles.contentContainer}>
        <Sidebar kw={kw} setDisplayList={setDisplayList} />
        <Papers displayList={displayList} />
      </div>
    </div>
  );
}

export default Research;
