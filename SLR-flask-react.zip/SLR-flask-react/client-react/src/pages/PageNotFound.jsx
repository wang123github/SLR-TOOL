import Nav from "../componets/Nav";

function PageNotFound() {
  return (
    <div>
      <Nav />
      <h1>Page Not Found</h1>{" "}
    </div>
  );
}

export default PageNotFound;
