import { BrowserRouter, Route, Routes } from "react-router-dom";
import Homepage from "./pages/Homepage";
import Research from "./pages/Research";
import PageNotFound from "./pages/PageNotFound";
import { useState } from "react";

function App() {
  const [kw, setKw] = useState({});

  return (
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<Homepage setKw={setKw} />} />

        <Route path="research" element={<Research kw={kw} />} />
        <Route path="*" element={<PageNotFound />} />
      </Routes>
    </BrowserRouter>
  );
}

export default App;
