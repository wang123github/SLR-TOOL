/*eslint-disable*/
import { useEffect, useState } from "react";
import styles from "./Sidebar.module.css";
import dataset from "../../public/dataset.json";

function oneWord_in_onePaper(paper, keyword) {
  let inTotal = 0;
  const abstractArrList = paper.abstract?.toLowerCase().split(/[ ,.;]+/);
  const keywordArrList = paper.keywords?.toLowerCase().split(" ");
  const titleArr = paper["paper title"]?.toLowerCase().split(" ");
  const summaryList = titleArr.concat(keywordArrList).concat(abstractArrList);
  summaryList.forEach((word) => {
    if (word === keyword) inTotal += 1;
  });
  return inTotal;
}

// ----- find :  1 - keyword papers
function one_kw_papers(dataset, keyword) {
  const one_kw_papers = []; //paper set contains one kw

  dataset.forEach((paper) => {
    if (
      paper.abstract
        ?.toLowerCase()
        .split(/[ ,.;]+/)
        .includes(keyword) ||
      paper["paper title"]?.toLowerCase().split(" ").includes(keyword) ||
      paper.keywords?.toLowerCase().split(" ").includes(keyword)
    ) {
      one_kw_papers.push({
        id: paper["paper id"],
        title: paper["paper title"],
        abstract: paper["abstract"],
        link: paper["link"],
        //add property the total key count
        keywordsCount: oneWord_in_onePaper(paper, keyword),
      });
    }
  });
  return one_kw_papers;
}

// find: 2 keyword papers
function two_kw_papers(dataset, key1, key2) {
  const two_kw_papers = [];

  dataset.forEach((paper) => {
    const abstract = paper.abstract?.toLowerCase().split(/[ ,.;]+/);
    const keywords = paper.keywords?.toLowerCase().split(" ");
    const paperTitle = paper["paper title"]?.toLowerCase().split(" ");

    if (
      (abstract?.includes(key1) && abstract?.includes(key2)) ||
      (keywords?.includes(key1) && keywords?.includes(key2)) ||
      (paperTitle?.includes(key1) && paperTitle?.includes(key2))
    ) {
      two_kw_papers.push({
        id: paper["paper id"],
        title: paper["paper title"],
        abstract: paper["abstract"],
        link: paper["link"],
        keywordsCount:
          oneWord_in_onePaper(paper, key1) + oneWord_in_onePaper(paper, key2),
      });
    }
  });
  return two_kw_papers;
}

//  ----- find :  3 - keyword papers
function three_kw_papers(dataset, key1, key2, key3) {
  const three_kw_papers = [];

  dataset.forEach((paper) => {
    const abstract = paper.abstract?.toLowerCase().split(/[ ,.;]+/);
    const keywords = paper.keywords?.toLowerCase().split(" ");
    const paperTitle = paper["paper title"]?.toLowerCase().split(" ");
    if (
      (abstract?.includes(key1) &&
        abstract?.includes(key2) &&
        abstract?.includes(key3)) ||
      (keywords?.includes(key1) &&
        keywords?.includes(key2) &&
        keywords?.includes(key3)) ||
      (paperTitle?.includes(key1) &&
        paperTitle?.includes(key2) &&
        paperTitle?.includes(key3))
    ) {
      three_kw_papers.push({
        id: paper["paper id"],
        title: paper["paper title"],
        abstract: paper["abstract"],
        link: paper["link"],
        keywordsCount:
          oneWord_in_onePaper(paper, key1) +
          oneWord_in_onePaper(paper, key2) +
          oneWord_in_onePaper(paper, key3),
      });
    }
  });
  return three_kw_papers;
}

function Sidebar({ kw, setDisplayList }) {
  const { kw01, kw02, kw03 } = kw;

  // const [dataset, setDataset] = useState([]);
  // const url = new URL("http://127.0.0.1:5000/dataset");
  // useEffect(function () {
  //   fetch(url, {
  //     mode: "no-cors",
  //   })
  //     .then((res) => res.json())
  //     .then((data) => setDataset(data))
  //     .catch((err) => console.error(err));
  // }, []);

  function handleKw01() {
    setDisplayList(one_kw_papers(dataset, kw01));
  }
  function handleKw02() {
    setDisplayList(one_kw_papers(dataset, kw02));
  }
  function handleKw03() {
    setDisplayList(one_kw_papers(dataset, kw03));
  }

  function handleKw0102() {
    setDisplayList(two_kw_papers(dataset, kw01, kw02));
  }
  function handleKw0103() {
    setDisplayList(two_kw_papers(dataset, kw01, kw03));
  }
  function handleKw0203() {
    setDisplayList(two_kw_papers(dataset, kw02, kw03));
  }
  function handleKw010203() {
    setDisplayList(three_kw_papers(dataset, kw01, kw02, kw03));
  }
  return (
    <>
      <div className={styles.sidebar}>
        <button value="kw01" onClick={handleKw01}>
          🔑{kw.kw01}
        </button>
        <button value="kw02" onClick={handleKw02}>
          🔑{kw.kw02}
        </button>
        <button value="kw03" onClick={handleKw03}>
          🔑{kw.kw03}
        </button>
        <h6>These concepts are also searched together:</h6>

        <button value="kw01-kw02" onClick={handleKw0102}>
          🔑{kw.kw01} 🔑{kw.kw02}
        </button>

        <button value="kw01-kw03" onClick={handleKw0103}>
          🔑{kw.kw01} 🔑{kw.kw03}
        </button>
        <button value="kw02-kw03" onClick={handleKw0203}>
          🔑{kw.kw02} 🔑{kw.kw03}
        </button>
        <button value="kw01-kw02-kw03" onClick={handleKw010203}>
          🔑{kw.kw01} 🔑{kw.kw02} 🔑{kw.kw03}
        </button>
      </div>
    </>
  );
}

export default Sidebar;
