import Nav from "../componets/Nav";
import styles from "./Homepage.module.css";
import KeywordForm from "../componets/KeywordForm";
/*eslint-disable*/
function Homepage({ setKw }) {
  return (
    <div className={styles.container}>
      <Nav />
      <div className={styles.contentContainer}>
        <p>
          The online SLR tool will make your research faster and easier.
          <br />
          Start by giving the keywords that you are interested in!😀
        </p>
        <KeywordForm setKw={setKw} />
      </div>
    </div>
  );
}

export default Homepage;
