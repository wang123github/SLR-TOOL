import { NavLink } from "react-router-dom";
import styles from "./Nav.module.css";

function Nav() {
  return (
    <nav className={styles.nav}>
      <ul>
        <li>
          <NavLink to="/" className={styles.link}>
            🏠 Back to Home
          </NavLink>
        </li>
        <li>
          <NavLink to="/research" className={styles.link}>
            🪕 Research
          </NavLink>
        </li>
      </ul>
    </nav>
  );
}

export default Nav;
